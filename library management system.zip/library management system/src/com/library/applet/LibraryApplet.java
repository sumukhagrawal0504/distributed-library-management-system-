package com.library.applet;

import java.applet.Applet;
import java.awt.*;
import java.awt.event.*;
import java.net.URL;
import java.net.MalformedURLException;

/**
 * Library Applet - Demonstrates Applet basics
 * Syllabus: Applet Basics, Applet HTML Tags & Attributes, Multimedia, URL Encapsulation
 * 
 * Note: Applets are deprecated in modern Java. This is for educational purposes.
 * Compile and run with: appletviewer LibraryApplet.html
 */
@SuppressWarnings("deprecation")
public class LibraryApplet extends Applet {
    private TextField searchField;
    private TextArea resultArea;
    private Label statusLabel;
    private String[][] sampleBooks = {
        {"1", "Java Complete Reference", "Herbert Schildt"},
        {"2", "Head First Java", "Kathy Sierra"},
        {"3", "Clean Code", "Robert Martin"},
        {"4", "Effective Java", "Joshua Bloch"},
        {"5", "Design Patterns", "Gang of Four"}
    };

    @Override
    public void init() {
        // Applet initialization
        setLayout(new BorderLayout());
        setBackground(Color.WHITE);

        // Header
        Label header = new Label("Library Search Applet", Label.CENTER);
        header.setFont(new Font("Arial", Font.BOLD, 18));
        add(header, BorderLayout.NORTH);

        // Search panel
        Panel searchPanel = new Panel(new FlowLayout());
        searchField = new TextField(20);
        Button searchBtn = new Button("Search");
        searchBtn.addActionListener(e -> performSearch());
        searchPanel.add(new Label("Search: "));
        searchPanel.add(searchField);
        searchPanel.add(searchBtn);

        // Results
        resultArea = new TextArea(10, 40);
        resultArea.setEditable(false);

        Panel centerPanel = new Panel(new BorderLayout());
        centerPanel.add(searchPanel, BorderLayout.NORTH);
        centerPanel.add(resultArea, BorderLayout.CENTER);
        add(centerPanel, BorderLayout.CENTER);

        // Status
        statusLabel = new Label("Applet initialized. Ready to search.");
        add(statusLabel, BorderLayout.SOUTH);

        showStatus("Library Applet loaded successfully");
    }

    @Override
    public void start() {
        statusLabel.setText("Applet started.");
        resultArea.setText("Welcome to Library Search Applet!\nEnter a title or author to search.\n\nAvailable books:\n");
        for (String[] book : sampleBooks) {
            resultArea.append("  [" + book[0] + "] " + book[1] + " by " + book[2] + "\n");
        }
    }

    @Override
    public void stop() {
        statusLabel.setText("Applet stopped.");
    }

    @Override
    public void destroy() {
        statusLabel.setText("Applet destroyed.");
    }

    private void performSearch() {
        String term = searchField.getText().toLowerCase();
        resultArea.setText("Search results for: '" + term + "'\n" + "=".repeat(40) + "\n");
        boolean found = false;
        for (String[] book : sampleBooks) {
            if (book[1].toLowerCase().contains(term) || book[2].toLowerCase().contains(term)) {
                resultArea.append("[" + book[0] + "] " + book[1] + " by " + book[2] + "\n");
                found = true;
            }
        }
        if (!found) resultArea.append("No books found.\n");
    }

    // URL Encapsulation demo
    public void demonstrateURL() {
        try {
            URL libraryUrl = new URL("http://library.example.com/catalog");
            resultArea.append("\nURL Demo:\n");
            resultArea.append("Protocol: " + libraryUrl.getProtocol() + "\n");
            resultArea.append("Host: " + libraryUrl.getHost() + "\n");
            resultArea.append("Path: " + libraryUrl.getPath() + "\n");
        } catch (MalformedURLException e) {
            resultArea.append("Invalid URL: " + e.getMessage() + "\n");
        }
    }

    @Override
    public String getAppletInfo() {
        return "Library Search Applet v1.0 - Library Management System";
    }
}
