package com.library.beans;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyVetoException;
import java.beans.VetoableChangeListener;

/**
 * Demonstrates JavaBean features: property change events, veto, indexed properties
 * Syllabus: JavaBeans, Property Types, Custom Event Types, BeanInfo
 */
public class BookBeanDemo {

    public static void demonstrate() {
        System.out.println("\n=== JavaBeans Demo ===");

        BookBean book = new BookBean();

        // Add PropertyChangeListener (Bound property)
        book.addPropertyChangeListener(new PropertyChangeListener() {
            @Override
            public void propertyChange(PropertyChangeEvent evt) {
                System.out.println("  Property Changed: " + evt.getPropertyName() + 
                    " [" + evt.getOldValue() + " -> " + evt.getNewValue() + "]");
            }
        });

        // Add VetoableChangeListener (Constrained property)
        book.addVetoableChangeListener(new VetoableChangeListener() {
            @Override
            public void vetoableChange(PropertyChangeEvent evt) throws PropertyVetoException {
                if ("quantity".equals(evt.getPropertyName())) {
                    int newVal = (int) evt.getNewValue();
                    if (newVal < 0) {
                        throw new PropertyVetoException("Quantity cannot be negative!", evt);
                    }
                }
            }
        });

        // Test simple property
        book.setTitle("Java: The Complete Reference");
        book.setAuthor("Herbert Schildt");
        System.out.println("Book: " + book);

        // Test bound property (triggers PropertyChangeListener)
        System.out.println("\nSetting price (bound property):");
        book.setPrice(599.0);
        book.setPrice(499.0);

        // Test constrained property
        System.out.println("\nSetting quantity (constrained property):");
        try {
            book.setQuantity(10);
            System.out.println("Quantity set to 10 - OK");
        } catch (PropertyVetoException e) {
            System.out.println("Vetoed: " + e.getMessage());
        }

        try {
            book.setQuantity(-5);
            System.out.println("Quantity set to -5 - OK");
        } catch (PropertyVetoException e) {
            System.out.println("Vetoed: " + e.getMessage());
        }

        // Test indexed property
        System.out.println("\nIndexed property (tags):");
        book.setTags(new String[]{"Java", "Programming", "Reference"});
        for (int i = 0; i < book.getTags().length; i++) {
            System.out.println("  Tag[" + i + "]: " + book.getTags(i));
        }

        // Test boolean property
        System.out.println("\nBoolean property - isAvailable: " + book.isAvailable());
    }
}
