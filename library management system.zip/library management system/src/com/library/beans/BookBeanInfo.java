package com.library.beans;

import java.beans.*;

/**
 * BeanInfo class for BookBean - Provides metadata about the bean
 * Syllabus: Using the BeanInfo Classes
 */
public class BookBeanInfo extends SimpleBeanInfo {

    @Override
    public PropertyDescriptor[] getPropertyDescriptors() {
        try {
            PropertyDescriptor titlePD = new PropertyDescriptor("title", BookBean.class);
            titlePD.setDisplayName("Book Title");
            titlePD.setShortDescription("The title of the book");

            PropertyDescriptor authorPD = new PropertyDescriptor("author", BookBean.class);
            authorPD.setDisplayName("Author Name");

            PropertyDescriptor pricePD = new PropertyDescriptor("price", BookBean.class);
            pricePD.setDisplayName("Price (Rs.)");
            pricePD.setBound(true);

            PropertyDescriptor quantityPD = new PropertyDescriptor("quantity", BookBean.class);
            quantityPD.setDisplayName("Quantity");
            quantityPD.setConstrained(true);

            PropertyDescriptor availablePD = new PropertyDescriptor("available", BookBean.class);
            availablePD.setDisplayName("Is Available");

            return new PropertyDescriptor[]{titlePD, authorPD, pricePD, quantityPD, availablePD};
        } catch (IntrospectionException e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public BeanDescriptor getBeanDescriptor() {
        BeanDescriptor bd = new BeanDescriptor(BookBean.class);
        bd.setDisplayName("Library Book Bean");
        bd.setShortDescription("A JavaBean representing a book in the library management system");
        return bd;
    }
}
