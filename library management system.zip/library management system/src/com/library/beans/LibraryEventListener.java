package com.library.beans;

import java.util.EventListener;

/**
 * Custom Event Listener for library events
 * Syllabus: Adding Custom Event Types, Creating JavaBean Class with Events
 */
public interface LibraryEventListener extends EventListener {
    void bookAdded(LibraryEvent event);
    void bookBorrowed(LibraryEvent event);
    void bookReturned(LibraryEvent event);
}
