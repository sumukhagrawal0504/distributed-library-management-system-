package com.library.beans;

import java.util.EventObject;

/**
 * Custom Event class for library events
 * Syllabus: Adding Custom Event Types
 */
public class LibraryEvent extends EventObject {
    private String eventType;
    private String message;
    private java.util.Date timestamp;

    public LibraryEvent(Object source, String eventType, String message) {
        super(source);
        this.eventType = eventType;
        this.message = message;
        this.timestamp = new java.util.Date();
    }

    public String getEventType() { return eventType; }
    public String getMessage() { return message; }
    public java.util.Date getTimestamp() { return timestamp; }

    @Override
    public String toString() {
        return "LibraryEvent{type='" + eventType + "', message='" + message + "', time=" + timestamp + "}";
    }
}
