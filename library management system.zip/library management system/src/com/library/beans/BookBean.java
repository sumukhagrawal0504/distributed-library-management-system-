package com.library.beans;

import java.beans.*;
import java.io.Serializable;

/**
 * JavaBean for Book - Follows JavaBeans conventions
 * Syllabus: JavaBeans Component Model, Property Types, BeanInfo
 * 
 * JavaBean Rules:
 * 1. Public no-arg constructor
 * 2. Implements Serializable
 * 3. Private properties with public getters/setters
 * 4. Supports PropertyChangeListener (bound properties)
 * 5. Supports VetoableChangeListener (constrained properties)
 */
public class BookBean implements Serializable {
    private static final long serialVersionUID = 1L;

    // Bound property support
    private PropertyChangeSupport propertyChangeSupport;
    // Constrained property support
    private VetoableChangeSupport vetoableChangeSupport;

    // Simple properties
    private String title;
    private String author;
    private String isbn;
    
    // Bound property (fires change events)
    private double price;
    
    // Constrained property (can be vetoed)
    private int quantity;
    
    // Indexed property
    private String[] tags;
    
    // Boolean property
    private boolean available;

    // Public no-arg constructor (JavaBean requirement)
    public BookBean() {
        propertyChangeSupport = new PropertyChangeSupport(this);
        vetoableChangeSupport = new VetoableChangeSupport(this);
        tags = new String[0];
        available = true;
    }

    // --- Simple Properties ---
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getAuthor() { return author; }
    public void setAuthor(String author) { this.author = author; }

    public String getIsbn() { return isbn; }
    public void setIsbn(String isbn) { this.isbn = isbn; }

    // --- Bound Property (notifies listeners on change) ---
    public double getPrice() { return price; }
    public void setPrice(double newPrice) {
        double oldPrice = this.price;
        this.price = newPrice;
        // Fire property change event
        propertyChangeSupport.firePropertyChange("price", oldPrice, newPrice);
    }

    // --- Constrained Property (listeners can veto changes) ---
    public int getQuantity() { return quantity; }
    public void setQuantity(int newQuantity) throws PropertyVetoException {
        int oldQuantity = this.quantity;
        // Allow listeners to veto the change
        vetoableChangeSupport.fireVetoableChange("quantity", oldQuantity, newQuantity);
        this.quantity = newQuantity;
        propertyChangeSupport.firePropertyChange("quantity", oldQuantity, newQuantity);
    }

    // --- Indexed Property ---
    public String[] getTags() { return tags; }
    public void setTags(String[] tags) { this.tags = tags; }
    
    public String getTags(int index) { return tags[index]; }
    public void setTags(int index, String tag) { tags[index] = tag; }

    // --- Boolean Property (uses 'is' prefix) ---
    public boolean isAvailable() { return available; }
    public void setAvailable(boolean available) { this.available = available; }

    // --- Event listener registration (Bound properties) ---
    public void addPropertyChangeListener(PropertyChangeListener listener) {
        propertyChangeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        propertyChangeSupport.removePropertyChangeListener(listener);
    }

    // --- Event listener registration (Constrained properties) ---
    public void addVetoableChangeListener(VetoableChangeListener listener) {
        vetoableChangeSupport.addVetoableChangeListener(listener);
    }

    public void removeVetoableChangeListener(VetoableChangeListener listener) {
        vetoableChangeSupport.removeVetoableChangeListener(listener);
    }

    @Override
    public String toString() {
        return "BookBean{title='" + title + "', author='" + author + "', price=" + price + 
               ", quantity=" + quantity + ", available=" + available + "}";
    }
}
