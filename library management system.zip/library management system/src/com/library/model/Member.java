package com.library.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Member entity - Demonstrates Inheritance (extends Person), Serialization
 * Syllabus: Inheritance, Serialization, Arrays
 */
public class Member extends Person implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private int memberId;
    private String membershipType; // STUDENT, FACULTY, GENERAL
    private Date memberSince;
    private List<Transaction> borrowHistory;
    private int maxBooksAllowed;

    public Member() {
        this.borrowHistory = new ArrayList<>();
    }

    public Member(int memberId, String name, String email, String phone, String membershipType) {
        super(name, email, phone);
        this.memberId = memberId;
        this.membershipType = membershipType;
        this.memberSince = new Date();
        this.borrowHistory = new ArrayList<>();
        setMaxBooksBasedOnType();
    }

    private void setMaxBooksBasedOnType() {
        switch (membershipType.toUpperCase()) {
            case "STUDENT":  maxBooksAllowed = 3; break;
            case "FACULTY":  maxBooksAllowed = 10; break;
            case "GENERAL":  maxBooksAllowed = 5; break;
            default:         maxBooksAllowed = 2; break;
        }
    }

    // Getters and Setters
    public int getMemberId() { return memberId; }
    public void setMemberId(int memberId) { this.memberId = memberId; }
    
    public String getMembershipType() { return membershipType; }
    public void setMembershipType(String membershipType) {
        this.membershipType = membershipType;
        setMaxBooksBasedOnType();
    }
    
    public Date getMemberSince() { return memberSince; }
    public void setMemberSince(Date memberSince) { this.memberSince = memberSince; }
    
    public List<Transaction> getBorrowHistory() { return borrowHistory; }
    
    public int getMaxBooksAllowed() { return maxBooksAllowed; }

    public void addTransaction(Transaction t) { borrowHistory.add(t); }

    public int getCurrentBorrowCount() {
        int count = 0;
        for (Transaction t : borrowHistory) {
            if (!t.isReturned()) count++;
        }
        return count;
    }

    public boolean canBorrow() {
        return getCurrentBorrowCount() < maxBooksAllowed;
    }

    @Override
    public String toString() {
        return String.format("Member[ID=%d, Name='%s', Email='%s', Type='%s', Books=%d/%d]",
                memberId, getName(), getEmail(), membershipType, getCurrentBorrowCount(), maxBooksAllowed);
    }
}
