package com.library.model;

import java.io.Serializable;

/**
 * Book entity - Demonstrates OOP concepts: Encapsulation, Serialization
 * Syllabus: Class and Object, Access Modifiers, Serialization
 */
public class Book implements Serializable, Comparable<Book> {
    private static final long serialVersionUID = 1L;
    
    private int bookId;
    private String title;
    private String author;
    private String isbn;
    private String genre;
    private int quantity;
    private int availableCopies;
    private double price;
    private boolean isAvailable;

    // Default Constructor
    public Book() {}

    // Parameterized Constructor
    public Book(int bookId, String title, String author, String isbn, String genre, int quantity, double price) {
        this.bookId = bookId;
        this.title = title;
        this.author = author;
        this.isbn = isbn;
        this.genre = genre;
        this.quantity = quantity;
        this.availableCopies = quantity;
        this.price = price;
        this.isAvailable = quantity > 0;
    }

    // Getters and Setters (Encapsulation)
    public int getBookId() { return bookId; }
    public void setBookId(int bookId) { this.bookId = bookId; }
    
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    
    public String getAuthor() { return author; }
    public void setAuthor(String author) { this.author = author; }
    
    public String getIsbn() { return isbn; }
    public void setIsbn(String isbn) { this.isbn = isbn; }
    
    public String getGenre() { return genre; }
    public void setGenre(String genre) { this.genre = genre; }
    
    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }
    
    public int getAvailableCopies() { return availableCopies; }
    public void setAvailableCopies(int availableCopies) {
        this.availableCopies = availableCopies;
        this.isAvailable = availableCopies > 0;
    }
    
    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }
    
    public boolean isAvailable() { return isAvailable; }

    public void borrowBook() {
        if (availableCopies > 0) {
            availableCopies--;
            isAvailable = availableCopies > 0;
        }
    }

    public void returnBook() {
        if (availableCopies < quantity) {
            availableCopies++;
            isAvailable = true;
        }
    }

    @Override
    public int compareTo(Book other) {
        return this.title.compareToIgnoreCase(other.title);
    }

    @Override
    public String toString() {
        return String.format("Book[ID=%d, Title='%s', Author='%s', ISBN='%s', Genre='%s', Available=%d/%d, Price=%.2f]",
                bookId, title, author, isbn, genre, availableCopies, quantity, price);
    }
}
