package com.library.model;

import java.io.Serializable;
import java.util.Date;

/**
 * Transaction entity for borrowing/returning books
 * Syllabus: Class and Object, Serialization
 */
public class Transaction implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private int transactionId;
    private int bookId;
    private int memberId;
    private Date borrowDate;
    private Date dueDate;
    private Date returnDate;
    private boolean returned;
    private double fine;

    public Transaction() {}

    public Transaction(int transactionId, int bookId, int memberId) {
        this.transactionId = transactionId;
        this.bookId = bookId;
        this.memberId = memberId;
        this.borrowDate = new Date();
        // Due date: 14 days from borrow date
        this.dueDate = new Date(borrowDate.getTime() + (14L * 24 * 60 * 60 * 1000));
        this.returned = false;
        this.fine = 0.0;
    }

    public int getTransactionId() { return transactionId; }
    public void setTransactionId(int transactionId) { this.transactionId = transactionId; }
    
    public int getBookId() { return bookId; }
    public void setBookId(int bookId) { this.bookId = bookId; }
    
    public int getMemberId() { return memberId; }
    public void setMemberId(int memberId) { this.memberId = memberId; }
    
    public Date getBorrowDate() { return borrowDate; }
    public void setBorrowDate(Date borrowDate) { this.borrowDate = borrowDate; }
    
    public Date getDueDate() { return dueDate; }
    public void setDueDate(Date dueDate) { this.dueDate = dueDate; }
    
    public Date getReturnDate() { return returnDate; }
    
    public boolean isReturned() { return returned; }
    
    public double getFine() { return fine; }

    public double calculateFine() {
        if (returned && returnDate != null && returnDate.after(dueDate)) {
            long diffDays = (returnDate.getTime() - dueDate.getTime()) / (24 * 60 * 60 * 1000);
            fine = diffDays * 2.0; // Rs. 2 per day late
        }
        return fine;
    }

    public void markReturned() {
        this.returnDate = new Date();
        this.returned = true;
        calculateFine();
    }

    @Override
    public String toString() {
        return String.format("Transaction[ID=%d, BookID=%d, MemberID=%d, Borrow=%s, Due=%s, Returned=%b, Fine=%.2f]",
                transactionId, bookId, memberId, borrowDate, dueDate, returned, fine);
    }
}
