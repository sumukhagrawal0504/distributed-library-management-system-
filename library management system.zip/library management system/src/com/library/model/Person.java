package com.library.model;

import java.io.Serializable;

/**
 * Abstract base class for all people in the system
 * Syllabus: Inheritance, Abstract classes, Access Modifiers
 */
public abstract class Person implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private String name;
    private String email;
    private String phone;

    public Person() {}

    public Person(String name, String email, String phone) {
        this.name = name;
        this.email = email;
        this.phone = phone;
    }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
}
