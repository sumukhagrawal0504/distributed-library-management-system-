package com.library.gui;

import com.library.service.LibraryService;
import com.library.model.*;
import com.library.exceptions.*;
import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

/**
 * Main Swing GUI Frame for Library Management System
 * Syllabus: Swing MVC, Layout Management, Text Input, Choice Components,
 *           Menus, Dialog Boxes, Component Organizers, Advance Swing Components
 */
public class LibraryMainFrame extends JFrame {
    private LibraryService libraryService;
    
    // Tabbed Pane (Component Organizer)
    private JTabbedPane tabbedPane;
    
    // Book Panel components
    private JTable bookTable;
    private DefaultTableModel bookTableModel;
    
    // Member Panel components
    private JTable memberTable;
    private DefaultTableModel memberTableModel;
    
    // Transaction Panel components
    private JTable transactionTable;
    private DefaultTableModel transactionTableModel;
    
    // Status bar
    private JLabel statusBar;
    private JProgressBar progressBar;

    public LibraryMainFrame(LibraryService service) {
        this.libraryService = service;
        initializeUI();
        loadSampleData();
        refreshAllTables();
    }

    private void initializeUI() {
        setTitle("Library Management System - Java Swing");
        setSize(1000, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Set Look and Feel
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        // === MENU BAR (Syllabus: Menus, Icons, Mnemonics, Accelerators) ===
        setJMenuBar(createMenuBar());
        
        // === TOOLBAR (Syllabus: Toolbars) ===
        add(createToolBar(), BorderLayout.NORTH);
        
        // === TABBED PANE (Syllabus: Tabbed Panes) ===
        tabbedPane = new JTabbedPane();
        tabbedPane.addTab("Books", createBookPanel());
        tabbedPane.addTab("Members", createMemberPanel());
        tabbedPane.addTab("Transactions", createTransactionPanel());
        tabbedPane.addTab("Search", createSearchPanel());
        add(tabbedPane, BorderLayout.CENTER);
        
        // === STATUS BAR with Progress Bar ===
        JPanel statusPanel = new JPanel(new BorderLayout());
        statusBar = new JLabel(" Ready");
        progressBar = new JProgressBar(0, 100);
        progressBar.setPreferredSize(new Dimension(150, 20));
        progressBar.setStringPainted(true);
        statusPanel.add(statusBar, BorderLayout.WEST);
        statusPanel.add(progressBar, BorderLayout.EAST);
        add(statusPanel, BorderLayout.SOUTH);
    }

    // ===================== MENU BAR =====================
    private JMenuBar createMenuBar() {
        JMenuBar menuBar = new JMenuBar();

        // File Menu
        JMenu fileMenu = new JMenu("File");
        fileMenu.setMnemonic(KeyEvent.VK_F); // Keyboard Mnemonic

        JMenuItem newItem = new JMenuItem("New Library", KeyEvent.VK_N);
        newItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N, InputEvent.CTRL_DOWN_MASK)); // Accelerator
        newItem.addActionListener(e -> {
            libraryService = new LibraryService();
            refreshAllTables();
            setStatus("New library created.");
        });

        JMenuItem exitItem = new JMenuItem("Exit");
        exitItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Q, InputEvent.CTRL_DOWN_MASK));
        exitItem.addActionListener(e -> System.exit(0));

        fileMenu.add(newItem);
        fileMenu.addSeparator();
        fileMenu.add(exitItem);

        // Edit Menu with CheckBox and Radio Button Menu Items
        JMenu editMenu = new JMenu("Edit");
        editMenu.setMnemonic(KeyEvent.VK_E);

        JCheckBoxMenuItem showIdColumn = new JCheckBoxMenuItem("Show ID Column", true);
        showIdColumn.addActionListener(e -> {
            // Toggle ID column visibility
            TableColumn col = bookTable.getColumnModel().getColumn(0);
            if (showIdColumn.isSelected()) {
                col.setMinWidth(50);
                col.setMaxWidth(100);
                col.setPreferredWidth(50);
            } else {
                col.setMinWidth(0);
                col.setMaxWidth(0);
                col.setPreferredWidth(0);
            }
        });

        // Radio Button Menu Items
        JMenu sortMenu = new JMenu("Sort Books By");
        ButtonGroup sortGroup = new ButtonGroup();
        JRadioButtonMenuItem sortByTitle = new JRadioButtonMenuItem("Title", true);
        JRadioButtonMenuItem sortByAuthor = new JRadioButtonMenuItem("Author");
        JRadioButtonMenuItem sortByPrice = new JRadioButtonMenuItem("Price");
        sortGroup.add(sortByTitle);
        sortGroup.add(sortByAuthor);
        sortGroup.add(sortByPrice);
        sortMenu.add(sortByTitle);
        sortMenu.add(sortByAuthor);
        sortMenu.add(sortByPrice);

        editMenu.add(showIdColumn);
        editMenu.add(sortMenu);

        // Help Menu
        JMenu helpMenu = new JMenu("Help");
        JMenuItem aboutItem = new JMenuItem("About");
        aboutItem.addActionListener(e -> JOptionPane.showMessageDialog(this,
                "Library Management System v1.0\nBuilt with Java Swing\nDemonstrates all syllabus topics",
                "About", JOptionPane.INFORMATION_MESSAGE));
        helpMenu.add(aboutItem);

        menuBar.add(fileMenu);
        menuBar.add(editMenu);
        menuBar.add(helpMenu);
        return menuBar;
    }

    // ===================== TOOLBAR =====================
    private JToolBar createToolBar() {
        JToolBar toolBar = new JToolBar();
        toolBar.setFloatable(false);

        JButton addBookBtn = new JButton("Add Book");
        addBookBtn.setToolTipText("Add a new book to the library"); // Tooltip
        addBookBtn.addActionListener(e -> showAddBookDialog());

        JButton addMemberBtn = new JButton("Add Member");
        addMemberBtn.setToolTipText("Register a new member");
        addMemberBtn.addActionListener(e -> showAddMemberDialog());

        JButton borrowBtn = new JButton("Borrow");
        borrowBtn.setToolTipText("Borrow a book");
        borrowBtn.addActionListener(e -> showBorrowDialog());

        JButton returnBtn = new JButton("Return");
        returnBtn.setToolTipText("Return a borrowed book");
        returnBtn.addActionListener(e -> showReturnDialog());

        JButton refreshBtn = new JButton("Refresh");
        refreshBtn.setToolTipText("Refresh all tables");
        refreshBtn.addActionListener(e -> refreshAllTables());

        toolBar.add(addBookBtn);
        toolBar.add(addMemberBtn);
        toolBar.addSeparator();
        toolBar.add(borrowBtn);
        toolBar.add(returnBtn);
        toolBar.addSeparator();
        toolBar.add(refreshBtn);

        return toolBar;
    }

    // ===================== BOOK PANEL (BorderLayout + Table) =====================
    private JPanel createBookPanel() {
        JPanel panel = new JPanel(new BorderLayout(5, 5)); // BorderLayout
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Table (Advanced Swing Component)
        String[] columns = {"ID", "Title", "Author", "ISBN", "Genre", "Available", "Total", "Price"};
        bookTableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int col) { return false; }
        };
        bookTable = new JTable(bookTableModel);
        bookTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        bookTable.setAutoCreateRowSorter(true);
        
        // Scroll Pane
        JScrollPane scrollPane = new JScrollPane(bookTable);

        // Button panel at bottom
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton addBtn = new JButton("Add Book");
        JButton editBtn = new JButton("Edit");
        JButton deleteBtn = new JButton("Delete");

        addBtn.addActionListener(e -> showAddBookDialog());
        deleteBtn.addActionListener(e -> deleteSelectedBook());

        buttonPanel.add(addBtn);
        buttonPanel.add(editBtn);
        buttonPanel.add(deleteBtn);

        panel.add(new JLabel("Book Catalog", SwingConstants.CENTER), BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(buttonPanel, BorderLayout.SOUTH);

        // Pop-up Menu (Syllabus: Pop-up Menus)
        JPopupMenu popupMenu = new JPopupMenu();
        JMenuItem viewItem = new JMenuItem("View Details");
        JMenuItem borrowItem = new JMenuItem("Borrow This Book");
        popupMenu.add(viewItem);
        popupMenu.add(borrowItem);
        bookTable.setComponentPopupMenu(popupMenu);

        viewItem.addActionListener(e -> {
            int row = bookTable.getSelectedRow();
            if (row >= 0) {
                int bookId = (int) bookTableModel.getValueAt(row, 0);
                Book b = libraryService.searchBookById(bookId);
                if (b != null) JOptionPane.showMessageDialog(this, b.toString(), "Book Details", JOptionPane.INFORMATION_MESSAGE);
            }
        });

        return panel;
    }

    // ===================== MEMBER PANEL (GridLayout) =====================
    private JPanel createMemberPanel() {
        JPanel panel = new JPanel(new BorderLayout(5, 5));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        String[] columns = {"ID", "Name", "Email", "Phone", "Type", "Books Borrowed"};
        memberTableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int col) { return false; }
        };
        memberTable = new JTable(memberTableModel);
        memberTable.setAutoCreateRowSorter(true);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton addBtn = new JButton("Register Member");
        JButton deleteBtn = new JButton("Remove");
        addBtn.addActionListener(e -> showAddMemberDialog());
        buttonPanel.add(addBtn);
        buttonPanel.add(deleteBtn);

        panel.add(new JLabel("Members", SwingConstants.CENTER), BorderLayout.NORTH);
        panel.add(new JScrollPane(memberTable), BorderLayout.CENTER);
        panel.add(buttonPanel, BorderLayout.SOUTH);
        return panel;
    }

    // ===================== TRANSACTION PANEL =====================
    private JPanel createTransactionPanel() {
        JPanel panel = new JPanel(new BorderLayout(5, 5));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        String[] columns = {"ID", "Book ID", "Member ID", "Borrow Date", "Due Date", "Return Date", "Returned", "Fine"};
        transactionTableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int col) { return false; }
        };
        transactionTable = new JTable(transactionTableModel);
        transactionTable.setAutoCreateRowSorter(true);

        // Split Pane (Component Organizer)
        JPanel summaryPanel = new JPanel();
        summaryPanel.setLayout(new BoxLayout(summaryPanel, BoxLayout.Y_AXIS));
        summaryPanel.setBorder(BorderFactory.createTitledBorder("Summary"));
        summaryPanel.setPreferredSize(new Dimension(200, 0));

        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
                new JScrollPane(transactionTable), summaryPanel);
        splitPane.setDividerLocation(700);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton borrowBtn = new JButton("Borrow Book");
        JButton returnBtn = new JButton("Return Book");
        borrowBtn.addActionListener(e -> showBorrowDialog());
        returnBtn.addActionListener(e -> showReturnDialog());
        buttonPanel.add(borrowBtn);
        buttonPanel.add(returnBtn);

        panel.add(new JLabel("Transactions", SwingConstants.CENTER), BorderLayout.NORTH);
        panel.add(splitPane, BorderLayout.CENTER);
        panel.add(buttonPanel, BorderLayout.SOUTH);
        return panel;
    }

    // ===================== SEARCH PANEL (GridBagLayout) =====================
    private JPanel createSearchPanel() {
        JPanel panel = new JPanel(new GridBagLayout()); // GridBagLayout
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Search Label
        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(new JLabel("Search:"), gbc);

        // Text Field (Text Input)
        JTextField searchField = new JTextField(20);
        gbc.gridx = 1; gbc.gridy = 0; gbc.gridwidth = 2;
        panel.add(searchField, gbc);

        // Radio Buttons (Choice Components)
        JRadioButton searchByTitle = new JRadioButton("By Title", true);
        JRadioButton searchByAuthor = new JRadioButton("By Author");
        ButtonGroup searchGroup = new ButtonGroup();
        searchGroup.add(searchByTitle);
        searchGroup.add(searchByAuthor);

        gbc.gridx = 0; gbc.gridy = 1; gbc.gridwidth = 1;
        panel.add(searchByTitle, gbc);
        gbc.gridx = 1;
        panel.add(searchByAuthor, gbc);

        // Combo Box (Choice Component)
        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 1;
        panel.add(new JLabel("Genre Filter:"), gbc);
        
        JComboBox<String> genreCombo = new JComboBox<>(new String[]{"All", "Fiction", "Non-Fiction", "Science", "History", "Programming"});
        gbc.gridx = 1; gbc.gridwidth = 2;
        panel.add(genreCombo, gbc);

        // Search Button
        JButton searchBtn = new JButton("Search");
        gbc.gridx = 1; gbc.gridy = 3; gbc.gridwidth = 1;
        panel.add(searchBtn, gbc);

        // Results area (Text Area with Scroll Pane)
        JTextArea resultsArea = new JTextArea(15, 50);
        resultsArea.setEditable(false);
        JScrollPane resultsScroll = new JScrollPane(resultsArea);
        gbc.gridx = 0; gbc.gridy = 4; gbc.gridwidth = 3;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0; gbc.weighty = 1.0;
        panel.add(resultsScroll, gbc);

        searchBtn.addActionListener(e -> {
            String term = searchField.getText().trim();
            if (term.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter a search term.");
                return;
            }
            List<Book> results;
            if (searchByTitle.isSelected()) {
                results = libraryService.searchBookByTitle(term);
            } else {
                results = libraryService.searchBookByAuthor(term);
            }

            resultsArea.setText("Search Results for: '" + term + "'\n");
            resultsArea.append("=" .repeat(60) + "\n");
            if (results.isEmpty()) {
                resultsArea.append("No books found.\n");
            } else {
                for (Book b : results) {
                    resultsArea.append(b.toString() + "\n");
                }
            }
            setStatus("Found " + results.size() + " results.");
        });

        return panel;
    }

    // ===================== DIALOGS (Syllabus: Dialog Boxes, Option Dialogs, Data Exchange) =====================

    private void showAddBookDialog() {
        JDialog dialog = new JDialog(this, "Add New Book", true); // Modal Dialog
        dialog.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JTextField titleField = new JTextField(20);
        JTextField authorField = new JTextField(20);
        JTextField isbnField = new JTextField(20);
        JComboBox<String> genreCombo = new JComboBox<>(new String[]{"Fiction", "Non-Fiction", "Science", "History", "Programming", "Other"});
        JSpinner quantitySpinner = new JSpinner(new SpinnerNumberModel(1, 1, 100, 1));
        JTextField priceField = new JTextField(10);

        // Labels and fields using GridBagLayout
        String[] labels = {"Title:", "Author:", "ISBN:", "Genre:", "Quantity:", "Price (Rs.):"};
        JComponent[] fields = {titleField, authorField, isbnField, genreCombo, quantitySpinner, priceField};
        
        for (int i = 0; i < labels.length; i++) {
            gbc.gridx = 0; gbc.gridy = i;
            dialog.add(new JLabel(labels[i]), gbc);
            gbc.gridx = 1;
            dialog.add(fields[i], gbc);
        }

        JButton saveBtn = new JButton("Save");
        JButton cancelBtn = new JButton("Cancel");
        JPanel btnPanel = new JPanel();
        btnPanel.add(saveBtn);
        btnPanel.add(cancelBtn);
        gbc.gridx = 0; gbc.gridy = labels.length; gbc.gridwidth = 2;
        dialog.add(btnPanel, gbc);

        saveBtn.addActionListener(e -> {
            try {
                int id = libraryService.getAllBooks().size() + 1;
                int qty = (int) quantitySpinner.getValue();
                double price = Double.parseDouble(priceField.getText());
                Book book = new Book(id, titleField.getText(), authorField.getText(),
                        isbnField.getText(), (String) genreCombo.getSelectedItem(), qty, price);
                libraryService.addBook(book);
                refreshBookTable();
                setStatus("Book added: " + book.getTitle());
                dialog.dispose();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(dialog, "Invalid price format!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        cancelBtn.addActionListener(e -> dialog.dispose());

        dialog.pack();
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

    private void showAddMemberDialog() {
        // Using JOptionPane for simple input (Option Dialogs)
        JTextField nameField = new JTextField();
        JTextField emailField = new JTextField();
        JTextField phoneField = new JTextField();
        JComboBox<String> typeCombo = new JComboBox<>(new String[]{"STUDENT", "FACULTY", "GENERAL"});

        Object[] message = {
            "Name:", nameField,
            "Email:", emailField,
            "Phone:", phoneField,
            "Type:", typeCombo
        };

        int option = JOptionPane.showConfirmDialog(this, message, "Register Member", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            int id = libraryService.getAllMembers().size() + 1;
            Member member = new Member(id, nameField.getText(), emailField.getText(),
                    phoneField.getText(), (String) typeCombo.getSelectedItem());
            libraryService.addMember(member);
            refreshMemberTable();
            setStatus("Member registered: " + member.getName());
        }
    }

    private void showBorrowDialog() {
        JTextField bookIdField = new JTextField();
        JTextField memberIdField = new JTextField();
        Object[] message = {"Book ID:", bookIdField, "Member ID:", memberIdField};

        int option = JOptionPane.showConfirmDialog(this, message, "Borrow Book", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            try {
                int bookId = Integer.parseInt(bookIdField.getText());
                int memberId = Integer.parseInt(memberIdField.getText());
                Transaction t = libraryService.borrowBook(bookId, memberId);
                refreshAllTables();
                setStatus("Book borrowed. Transaction #" + t.getTransactionId());
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Invalid ID format!", "Error", JOptionPane.ERROR_MESSAGE);
            } catch (LibraryException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.WARNING_MESSAGE);
            }
        }
    }

    private void showReturnDialog() {
        String input = JOptionPane.showInputDialog(this, "Enter Transaction ID to return:");
        if (input != null) {
            try {
                int transId = Integer.parseInt(input);
                Transaction t = libraryService.returnBook(transId);
                refreshAllTables();
                String msg = t.getFine() > 0 ? "Book returned. Fine: Rs. " + t.getFine() : "Book returned. No fine.";
                JOptionPane.showMessageDialog(this, msg, "Return", JOptionPane.INFORMATION_MESSAGE);
                setStatus(msg);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Invalid ID!", "Error", JOptionPane.ERROR_MESSAGE);
            } catch (LibraryException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Error", JOptionPane.WARNING_MESSAGE);
            }
        }
    }

    private void deleteSelectedBook() {
        int row = bookTable.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Select a book to delete.");
            return;
        }
        int bookId = (int) bookTableModel.getValueAt(row, 0);
        int confirm = JOptionPane.showConfirmDialog(this, "Delete book ID " + bookId + "?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            libraryService.removeBook(bookId);
            refreshBookTable();
            setStatus("Book deleted.");
        }
    }

    // ===================== TABLE REFRESH =====================
    private void refreshBookTable() {
        bookTableModel.setRowCount(0);
        for (Book b : libraryService.getAllBooks()) {
            bookTableModel.addRow(new Object[]{b.getBookId(), b.getTitle(), b.getAuthor(),
                    b.getIsbn(), b.getGenre(), b.getAvailableCopies(), b.getQuantity(), b.getPrice()});
        }
    }

    private void refreshMemberTable() {
        memberTableModel.setRowCount(0);
        for (Member m : libraryService.getAllMembers()) {
            memberTableModel.addRow(new Object[]{m.getMemberId(), m.getName(), m.getEmail(),
                    m.getPhone(), m.getMembershipType(), m.getCurrentBorrowCount()});
        }
    }

    private void refreshTransactionTable() {
        transactionTableModel.setRowCount(0);
        for (Transaction t : libraryService.getAllTransactions()) {
            transactionTableModel.addRow(new Object[]{t.getTransactionId(), t.getBookId(), t.getMemberId(),
                    t.getBorrowDate(), t.getDueDate(), t.getReturnDate(), t.isReturned() ? "Yes" : "No", t.getFine()});
        }
    }

    private void refreshAllTables() {
        refreshBookTable();
        refreshMemberTable();
        refreshTransactionTable();
    }

    private void setStatus(String msg) {
        statusBar.setText(" " + msg);
    }

    // ===================== SAMPLE DATA =====================
    private void loadSampleData() {
        libraryService.addBook(new Book(1, "Java: The Complete Reference", "Herbert Schildt", "978-0071808552", "Programming", 5, 599.0));
        libraryService.addBook(new Book(2, "Head First Java", "Kathy Sierra", "978-0596009205", "Programming", 3, 499.0));
        libraryService.addBook(new Book(3, "Clean Code", "Robert C. Martin", "978-0132350884", "Programming", 2, 450.0));
        libraryService.addBook(new Book(4, "The Great Gatsby", "F. Scott Fitzgerald", "978-0743273565", "Fiction", 4, 299.0));
        libraryService.addBook(new Book(5, "A Brief History of Time", "Stephen Hawking", "978-0553380163", "Science", 3, 350.0));
        libraryService.addBook(new Book(6, "Data Structures using Java", "Langsam Augenstein", "978-0130477217", "Programming", 4, 550.0));

        libraryService.addMember(new Member(1, "Rahul Sharma", "rahul@email.com", "9876543210", "STUDENT"));
        libraryService.addMember(new Member(2, "Dr. Priya Patel", "priya@university.edu", "9876543211", "FACULTY"));
        libraryService.addMember(new Member(3, "Amit Kumar", "amit@email.com", "9876543212", "GENERAL"));
    }
}
