package com.library.networking;

import java.io.*;
import java.net.*;

/**
 * Socket Client for Library System
 * Syllabus: Networking - Working with Sockets
 */
public class LibraryClient {
    private static final String SERVER_HOST = "localhost";
    private static final int SERVER_PORT = 5000;

    public static void connectToServer() {
        System.out.println("Connecting to Library Server...");
        
        try (Socket socket = new Socket(SERVER_HOST, SERVER_PORT);
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
             BufferedReader console = new BufferedReader(new InputStreamReader(System.in))) {
            
            // Read welcome message
            System.out.println("Server: " + in.readLine());
            System.out.println("Server: " + in.readLine());
            
            String userInput;
            System.out.print("Enter command: ");
            while ((userInput = console.readLine()) != null) {
                out.println(userInput);
                String response = in.readLine();
                System.out.println("Server: " + response);
                
                if (userInput.equalsIgnoreCase("QUIT")) break;
                System.out.print("Enter command: ");
            }
        } catch (ConnectException e) {
            System.err.println("Cannot connect to server. Is the server running?");
        } catch (IOException e) {
            System.err.println("Client error: " + e.getMessage());
        }
    }
}
