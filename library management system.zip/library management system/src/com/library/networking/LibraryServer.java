package com.library.networking;

import java.io.*;
import java.net.*;

/**
 * Simple Socket Server for Library System
 * Syllabus: Networking - Working with Sockets, Working with URLs
 */
public class LibraryServer {
    private static final int PORT = 5000;

    public static void startServer() {
        System.out.println("Library Server starting on port " + PORT + "...");
        
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Server started. Waiting for connections...");
            
            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("Client connected: " + clientSocket.getInetAddress());
                
                // Handle each client in a new thread
                new Thread(() -> handleClient(clientSocket)).start();
            }
        } catch (IOException e) {
            System.err.println("Server error: " + e.getMessage());
        }
    }

    private static void handleClient(Socket socket) {
        try (BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true)) {
            
            out.println("Welcome to Library Server!");
            out.println("Commands: SEARCH <title>, LIST, QUIT");
            
            String input;
            while ((input = in.readLine()) != null) {
                System.out.println("Received: " + input);
                
                if (input.equalsIgnoreCase("QUIT")) {
                    out.println("Goodbye!");
                    break;
                } else if (input.equalsIgnoreCase("LIST")) {
                    out.println("Books: Java Complete Reference, Head First Java, Clean Code, Effective Java");
                } else if (input.toUpperCase().startsWith("SEARCH ")) {
                    String term = input.substring(7);
                    out.println("Searching for: " + term + "... (Demo: Results would come from DB)");
                } else {
                    out.println("Unknown command. Try: SEARCH <title>, LIST, QUIT");
                }
            }
        } catch (IOException e) {
            System.err.println("Client handler error: " + e.getMessage());
        }
    }

    // URL demonstration
    public static void demonstrateURL() {
        System.out.println("\n=== URL Demo ===");
        try {
            URL url = new URL("http://library.example.com:8080/api/books?genre=java#section1");
            System.out.println("Protocol: " + url.getProtocol());
            System.out.println("Host: " + url.getHost());
            System.out.println("Port: " + url.getPort());
            System.out.println("Path: " + url.getPath());
            System.out.println("Query: " + url.getQuery());
            System.out.println("Ref: " + url.getRef());
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
    }
}
