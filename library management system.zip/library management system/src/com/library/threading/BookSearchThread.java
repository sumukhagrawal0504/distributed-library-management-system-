package com.library.threading;

import com.library.model.Book;
import java.util.ArrayList;
import java.util.List;

/**
 * Demonstrates multithreading for parallel book search
 * Syllabus: Creating Multithreaded Programs, Thread Life Cycle
 */
public class BookSearchThread extends Thread {
    private List<Book> books;
    private String searchTerm;
    private String searchType; // "title" or "author"
    private List<Book> results;

    public BookSearchThread(String name, List<Book> books, String searchTerm, String searchType) {
        super(name);
        this.books = books;
        this.searchTerm = searchTerm.toLowerCase();
        this.searchType = searchType;
        this.results = new ArrayList<>();
    }

    @Override
    public void run() {
        System.out.println(Thread.currentThread().getName() + " - Search started (State: " + getState() + ")");
        try {
            for (Book b : books) {
                String field = searchType.equals("title") ? b.getTitle() : b.getAuthor();
                if (field.toLowerCase().contains(searchTerm)) {
                    results.add(b);
                }
                Thread.sleep(50); // Simulate processing time
            }
        } catch (InterruptedException e) {
            System.out.println(getName() + " was interrupted!");
            Thread.currentThread().interrupt();
        }
        System.out.println(getName() + " - Search complete. Found " + results.size() + " results.");
    }

    public List<Book> getResults() { return results; }
}
