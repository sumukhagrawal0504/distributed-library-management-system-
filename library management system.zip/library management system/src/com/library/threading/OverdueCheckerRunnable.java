package com.library.threading;

import com.library.model.Transaction;
import java.util.Date;
import java.util.List;

/**
 * Runnable implementation for checking overdue books
 * Syllabus: Threading - Runnable interface, Thread Life Cycle
 */
public class OverdueCheckerRunnable implements Runnable {
    private List<Transaction> transactions;
    private volatile boolean running = true;

    public OverdueCheckerRunnable(List<Transaction> transactions) {
        this.transactions = transactions;
    }

    public void stop() {
        running = false;
    }

    @Override
    public void run() {
        System.out.println("Overdue Checker Thread started - " + Thread.currentThread().getName());
        Date now = new Date();
        int overdueCount = 0;
        
        for (Transaction t : transactions) {
            if (!running) break;
            if (!t.isReturned() && t.getDueDate().before(now)) {
                overdueCount++;
                System.out.println("  OVERDUE: Transaction #" + t.getTransactionId() + 
                    " (Book ID: " + t.getBookId() + ", Member ID: " + t.getMemberId() + 
                    ", Due: " + t.getDueDate() + ")");
            }
        }
        System.out.println("Overdue check complete. Found " + overdueCount + " overdue items.");
    }
}
