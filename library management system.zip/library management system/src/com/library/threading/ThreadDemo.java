package com.library.threading;

import com.library.model.Book;
import com.library.model.Transaction;
import java.util.Arrays;
import java.util.List;

/**
 * Demonstrates Thread Life Cycle, synchronization, and multi-threading
 * Syllabus: Thread Life Cycle, Creating Multithreaded Programs
 */
public class ThreadDemo {

    public static void demonstrateThreadLifeCycle() {
        System.out.println("\n=== Thread Life Cycle Demo ===");
        
        Thread thread = new Thread(() -> {
            System.out.println("Thread is RUNNING: " + Thread.currentThread().getName());
            try {
                Thread.sleep(1000); // TIMED_WAITING state
                System.out.println("Thread woke up from sleep");
            } catch (InterruptedException e) {
                System.out.println("Thread interrupted");
            }
        }, "LifeCycleThread");

        System.out.println("State after creation (NEW): " + thread.getState());
        thread.start();
        System.out.println("State after start (RUNNABLE): " + thread.getState());

        try {
            Thread.sleep(100);
            System.out.println("State during sleep (TIMED_WAITING): " + thread.getState());
            thread.join(); // Wait for thread to finish
            System.out.println("State after join (TERMINATED): " + thread.getState());
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static void demonstrateParallelSearch(List<Book> books) {
        System.out.println("\n=== Parallel Book Search Demo ===");
        
        BookSearchThread titleSearch = new BookSearchThread("TitleSearchThread", books, "java", "title");
        BookSearchThread authorSearch = new BookSearchThread("AuthorSearchThread", books, "herbert", "author");

        titleSearch.start();
        authorSearch.start();

        try {
            titleSearch.join();
            authorSearch.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("Title search results: " + titleSearch.getResults().size());
        System.out.println("Author search results: " + authorSearch.getResults().size());
    }

    public static void demonstrateOverdueChecker(List<Transaction> transactions) {
        System.out.println("\n=== Overdue Checker (Runnable) Demo ===");
        OverdueCheckerRunnable checker = new OverdueCheckerRunnable(transactions);
        Thread checkerThread = new Thread(checker, "OverdueCheckerThread");
        checkerThread.start();
        try {
            checkerThread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
