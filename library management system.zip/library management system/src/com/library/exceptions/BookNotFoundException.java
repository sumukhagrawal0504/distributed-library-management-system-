package com.library.exceptions;

/**
 * Custom exception for book not found scenarios
 * Syllabus: Exception Handling - Try, Catch, Finally, Throws
 */
public class BookNotFoundException extends LibraryException {
    public BookNotFoundException(String message) {
        super(message);
    }
    
    public BookNotFoundException(int bookId) {
        super("Book with ID " + bookId + " not found in the library.");
    }
}
