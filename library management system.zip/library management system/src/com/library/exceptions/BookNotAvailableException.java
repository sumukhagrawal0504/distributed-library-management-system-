package com.library.exceptions;

/**
 * Custom exception for book not available
 * Syllabus: Exception Handling
 */
public class BookNotAvailableException extends LibraryException {
    public BookNotAvailableException(String message) {
        super(message);
    }
}
