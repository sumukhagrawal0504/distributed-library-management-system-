package com.library.exceptions;

/**
 * Custom exception for member not found
 * Syllabus: Exception Handling
 */
public class MemberNotFoundException extends LibraryException {
    public MemberNotFoundException(String message) {
        super(message);
    }
    
    public MemberNotFoundException(int memberId) {
        super("Member with ID " + memberId + " not found.");
    }
}
