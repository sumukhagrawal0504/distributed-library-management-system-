package com.library.exceptions;

/**
 * Base exception for library system
 * Syllabus: Exception Handling - Creating custom exceptions
 */
public class LibraryException extends Exception {
    public LibraryException(String message) {
        super(message);
    }
    
    public LibraryException(String message, Throwable cause) {
        super(message, cause);
    }
}
