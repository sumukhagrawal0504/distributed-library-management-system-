package com.library.exceptions;

/**
 * Custom exception when member exceeds max borrow limit
 * Syllabus: Exception Handling
 */
public class MaxBooksExceededException extends LibraryException {
    public MaxBooksExceededException(String message) {
        super(message);
    }
}
