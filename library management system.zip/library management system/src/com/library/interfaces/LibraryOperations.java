package com.library.interfaces;

import com.library.model.Book;
import com.library.model.Member;
import com.library.model.Transaction;
import java.util.List;

/**
 * Interface defining core library operations
 * Syllabus: Interfaces
 */
public interface LibraryOperations {
    void addBook(Book book);
    void removeBook(int bookId);
    Book searchBookById(int bookId);
    List<Book> searchBookByTitle(String title);
    List<Book> searchBookByAuthor(String author);
    List<Book> getAllBooks();
    
    void addMember(Member member);
    void removeMember(int memberId);
    Member searchMemberById(int memberId);
    List<Member> getAllMembers();
    
    Transaction borrowBook(int bookId, int memberId) throws Exception;
    Transaction returnBook(int transactionId) throws Exception;
    List<Transaction> getAllTransactions();
}
