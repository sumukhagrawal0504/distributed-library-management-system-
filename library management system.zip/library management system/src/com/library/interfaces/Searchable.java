package com.library.interfaces;

import java.util.List;

/**
 * Generic search interface
 * Syllabus: Interfaces
 */
public interface Searchable<T> {
    List<T> search(String keyword);
    T findById(int id);
}
