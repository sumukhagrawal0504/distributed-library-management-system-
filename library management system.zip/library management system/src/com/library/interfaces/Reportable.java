package com.library.interfaces;

/**
 * Interface for generating reports
 * Syllabus: Interfaces
 */
public interface Reportable {
    String generateReport();
    void printReport();
}
