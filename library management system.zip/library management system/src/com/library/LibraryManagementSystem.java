package com.library;

/*
cd src
javac -d .. (Get-ChildItem -Recurse *.java | Where-Object { $_.FullName -notmatch "ejb|servlet" })
cd ..
java com.library.LibraryManagementSystem

*/

import com.library.model.*;
import com.library.service.LibraryService;
import com.library.exceptions.*;
import com.library.io.FileHandler;
import com.library.threading.ThreadDemo;
import com.library.beans.BookBeanDemo;
import com.library.gui.LibraryMainFrame;
import javax.swing.*;
import java.util.*;

/**
 * Main Application - Library Management System
 * Demonstrates ALL syllabus topics across 5 units
 * 
 * Run modes:
 *   java com.library.LibraryManagementSystem         -> Console + GUI
 *   java com.library.LibraryManagementSystem console  -> Console only
 *   java com.library.LibraryManagementSystem gui      -> GUI only
 */
public class LibraryManagementSystem {
    private static LibraryService libraryService = new LibraryService();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("╔══════════════════════════════════════════════════╗");
        System.out.println("║     LIBRARY MANAGEMENT SYSTEM - Java Edition    ║");
        System.out.println("║     Covering Complete Java Syllabus (Unit 1-5)  ║");
        System.out.println("╚══════════════════════════════════════════════════╝\n");

        String mode = args.length > 0 ? args[0].toLowerCase() : "both";

        // Load sample data
        loadSampleData();

        if (mode.equals("gui")) {
            launchGUI();
        } else if (mode.equals("console")) {
            runConsoleMode();
        } else {
            // Demo all features then launch GUI
            runDemos();
            System.out.println("\n--- Launching Swing GUI ---");
            launchGUI();
        }
    }

    private static void runDemos() {
        // UNIT 1: OOP Demos
        System.out.println("\n========== UNIT 1: OOP Concepts ==========");
        demonstrateOOP();
        demonstrateExceptionHandling();
        
        // UNIT 1: Threading
        System.out.println("\n========== UNIT 1: Threading ==========");
        ThreadDemo.demonstrateThreadLifeCycle();
        ThreadDemo.demonstrateParallelSearch(libraryService.getAllBooks());
        ThreadDemo.demonstrateOverdueChecker(libraryService.getAllTransactions());
        
        // UNIT 1: I/O and Serialization
        System.out.println("\n========== UNIT 1: I/O & Serialization ==========");
        demonstrateIO();
        
        // UNIT 2: JavaBeans
        System.out.println("\n========== UNIT 2: JavaBeans ==========");
        BookBeanDemo.demonstrate();
        
        System.out.println("\n========== All Demos Complete ==========");
    }

    private static void demonstrateOOP() {
        System.out.println("\n--- OOP: Inheritance, Polymorphism, Arrays ---");
        
        // Arrays demonstration
        Book[] booksArray = libraryService.getBooksAsArray();
        System.out.println("Books array length: " + booksArray.length);
        Arrays.sort(booksArray); // Uses Comparable interface
        System.out.println("Books sorted by title:");
        for (Book b : booksArray) {
            System.out.println("  " + b.getTitle());
        }

        // Polymorphism - Member is-a Person
        Person person = libraryService.getAllMembers().get(0);
        System.out.println("\nPolymorphism - Person reference: " + person.getName());
    }

    private static void demonstrateExceptionHandling() {
        System.out.println("\n--- Exception Handling: Try, Catch, Finally, Throws ---");
        
        // Try-Catch-Finally demo
        try {
            System.out.println("Trying to borrow non-existent book...");
            libraryService.borrowBook(999, 1); // Will throw BookNotFoundException
        } catch (BookNotFoundException e) {
            System.out.println("Caught BookNotFoundException: " + e.getMessage());
        } catch (LibraryException e) {
            System.out.println("Caught LibraryException: " + e.getMessage());
        } finally {
            System.out.println("Finally block executed (cleanup).");
        }

        // Borrow beyond limit demo
        try {
            System.out.println("\nBorrowing books for student (max 3)...");
            libraryService.borrowBook(1, 1);
            libraryService.borrowBook(2, 1);
            libraryService.borrowBook(3, 1);
            System.out.println("Trying 4th book (should fail)...");
            libraryService.borrowBook(4, 1); // Should throw MaxBooksExceededException
        } catch (MaxBooksExceededException e) {
            System.out.println("Caught MaxBooksExceededException: " + e.getMessage());
        } catch (LibraryException e) {
            System.out.println("Caught: " + e.getMessage());
        }
    }

    private static void demonstrateIO() {
        // Serialization
        FileHandler.saveBooks(libraryService.getAllBooks(), "library_books.ser");
        List<Book> loadedBooks = FileHandler.loadBooks("library_books.ser");
        System.out.println("Deserialized " + loadedBooks.size() + " books.");

        // Text I/O
        FileHandler.exportBookCatalog(libraryService.getAllBooks(), "book_catalog.txt");
        FileHandler.readCatalog("book_catalog.txt");
    }

    private static void runConsoleMode() {
        boolean running = true;
        while (running) {
            System.out.println("\n--- Library Management System ---");
            System.out.println("1. View All Books");
            System.out.println("2. View All Members");
            System.out.println("3. Search Book by Title");
            System.out.println("4. Borrow Book");
            System.out.println("5. Return Book");
            System.out.println("6. View Transactions");
            System.out.println("7. Add New Book");
            System.out.println("8. Add New Member");
            System.out.println("9. Run Threading Demo");
            System.out.println("10. Run JavaBeans Demo");
            System.out.println("11. Save & Export Data");
            System.out.println("0. Exit");
            System.out.print("Choice: ");

            try {
                int choice = scanner.nextInt();
                scanner.nextLine();

                switch (choice) {
                    case 1: viewAllBooks(); break;
                    case 2: viewAllMembers(); break;
                    case 3: searchBooks(); break;
                    case 4: borrowBook(); break;
                    case 5: returnBook(); break;
                    case 6: viewTransactions(); break;
                    case 7: addBook(); break;
                    case 8: addMember(); break;
                    case 9:
                        ThreadDemo.demonstrateThreadLifeCycle();
                        ThreadDemo.demonstrateParallelSearch(libraryService.getAllBooks());
                        break;
                    case 10: BookBeanDemo.demonstrate(); break;
                    case 11: demonstrateIO(); break;
                    case 0: running = false; System.out.println("Goodbye!"); break;
                    default: System.out.println("Invalid choice.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Please enter a valid number.");
                scanner.nextLine();
            }
        }
    }

    private static void viewAllBooks() {
        System.out.println("\n--- All Books ---");
        System.out.printf("%-5s %-35s %-20s %-10s %-10s%n", "ID", "Title", "Author", "Available", "Price");
        System.out.println("-".repeat(85));
        for (Book b : libraryService.getAllBooks()) {
            System.out.printf("%-5d %-35s %-20s %-10d Rs.%-7.2f%n",
                    b.getBookId(), b.getTitle(), b.getAuthor(), b.getAvailableCopies(), b.getPrice());
        }
    }

    private static void viewAllMembers() {
        System.out.println("\n--- All Members ---");
        for (Member m : libraryService.getAllMembers()) {
            System.out.println(m);
        }
    }

    private static void searchBooks() {
        System.out.print("Enter search term: ");
        String term = scanner.nextLine();
        List<Book> results = libraryService.searchBookByTitle(term);
        if (results.isEmpty()) System.out.println("No books found.");
        else results.forEach(System.out::println);
    }

    private static void borrowBook() {
        try {
            System.out.print("Book ID: ");
            int bookId = scanner.nextInt();
            System.out.print("Member ID: ");
            int memberId = scanner.nextInt();
            scanner.nextLine();
            Transaction t = libraryService.borrowBook(bookId, memberId);
            System.out.println("Success! " + t);
        } catch (LibraryException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void returnBook() {
        try {
            System.out.print("Transaction ID: ");
            int transId = scanner.nextInt();
            scanner.nextLine();
            Transaction t = libraryService.returnBook(transId);
            System.out.println("Returned! Fine: Rs. " + t.getFine());
        } catch (LibraryException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void viewTransactions() {
        System.out.println("\n--- Transactions ---");
        for (Transaction t : libraryService.getAllTransactions()) {
            System.out.println(t);
        }
    }

    private static void addBook() {
        System.out.print("Title: "); String title = scanner.nextLine();
        System.out.print("Author: "); String author = scanner.nextLine();
        System.out.print("ISBN: "); String isbn = scanner.nextLine();
        System.out.print("Genre: "); String genre = scanner.nextLine();
        System.out.print("Quantity: "); int qty = scanner.nextInt();
        System.out.print("Price: "); double price = scanner.nextDouble();
        scanner.nextLine();
        int id = libraryService.getAllBooks().size() + 1;
        libraryService.addBook(new Book(id, title, author, isbn, genre, qty, price));
    }

    private static void addMember() {
        System.out.print("Name: "); String name = scanner.nextLine();
        System.out.print("Email: "); String email = scanner.nextLine();
        System.out.print("Phone: "); String phone = scanner.nextLine();
        System.out.print("Type (STUDENT/FACULTY/GENERAL): "); String type = scanner.nextLine();
        int id = libraryService.getAllMembers().size() + 1;
        libraryService.addMember(new Member(id, name, email, phone, type));
    }

    private static void loadSampleData() {
        libraryService.addBook(new Book(1, "Java: The Complete Reference", "Herbert Schildt", "978-0071808552", "Programming", 5, 599.0));
        libraryService.addBook(new Book(2, "Head First Java", "Kathy Sierra", "978-0596009205", "Programming", 3, 499.0));
        libraryService.addBook(new Book(3, "Clean Code", "Robert C. Martin", "978-0132350884", "Programming", 2, 450.0));
        libraryService.addBook(new Book(4, "The Great Gatsby", "F. Scott Fitzgerald", "978-0743273565", "Fiction", 4, 299.0));
        libraryService.addBook(new Book(5, "A Brief History of Time", "Stephen Hawking", "978-0553380163", "Science", 3, 350.0));
        libraryService.addBook(new Book(6, "Data Structures using Java", "Langsam Augenstein", "978-0130477217", "Programming", 4, 550.0));

        libraryService.addMember(new Member(1, "Rahul Sharma", "rahul@email.com", "9876543210", "STUDENT"));
        libraryService.addMember(new Member(2, "Dr. Priya Patel", "priya@university.edu", "9876543211", "FACULTY"));
        libraryService.addMember(new Member(3, "Amit Kumar", "amit@email.com", "9876543212", "GENERAL"));
    }

    private static void launchGUI() {
        SwingUtilities.invokeLater(() -> {
            LibraryMainFrame frame = new LibraryMainFrame(libraryService);
            frame.setVisible(true);
        });
    }
}
