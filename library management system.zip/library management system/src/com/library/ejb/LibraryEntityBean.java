package com.library.ejb;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Entity EJB (JPA Entity) for Book
 * Syllabus: Entity EJBs
 * 
 * Note: Modern Java EE uses JPA instead of Entity Beans.
 * This demonstrates the concept using JPA annotations.
 */
@Entity
@Table(name = "books")
@NamedQueries({
    @NamedQuery(name = "BookEntity.findAll", query = "SELECT b FROM LibraryEntityBean b"),
    @NamedQuery(name = "BookEntity.findByTitle", query = "SELECT b FROM LibraryEntityBean b WHERE b.title LIKE :title"),
    @NamedQuery(name = "BookEntity.findByAuthor", query = "SELECT b FROM LibraryEntityBean b WHERE b.author = :author")
})
public class LibraryEntityBean implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "book_id")
    private int bookId;

    @Column(name = "title", nullable = false, length = 255)
    private String title;

    @Column(name = "author", nullable = false, length = 255)
    private String author;

    @Column(name = "isbn", unique = true, length = 20)
    private String isbn;

    @Column(name = "genre", length = 100)
    private String genre;

    @Column(name = "quantity")
    private int quantity;

    @Column(name = "available_copies")
    private int availableCopies;

    @Column(name = "price")
    private double price;

    // Default constructor required by JPA
    public LibraryEntityBean() {}

    public LibraryEntityBean(String title, String author, String isbn, String genre, int quantity, double price) {
        this.title = title;
        this.author = author;
        this.isbn = isbn;
        this.genre = genre;
        this.quantity = quantity;
        this.availableCopies = quantity;
        this.price = price;
    }

    // Getters and Setters
    public int getBookId() { return bookId; }
    public void setBookId(int bookId) { this.bookId = bookId; }
    
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    
    public String getAuthor() { return author; }
    public void setAuthor(String author) { this.author = author; }
    
    public String getIsbn() { return isbn; }
    public void setIsbn(String isbn) { this.isbn = isbn; }
    
    public String getGenre() { return genre; }
    public void setGenre(String genre) { this.genre = genre; }
    
    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }
    
    public int getAvailableCopies() { return availableCopies; }
    public void setAvailableCopies(int copies) { this.availableCopies = copies; }
    
    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }

    @Override
    public String toString() {
        return "BookEntity{id=" + bookId + ", title='" + title + "', author='" + author + "'}";
    }
}
