package com.library.ejb;

import javax.ejb.*;
import javax.jms.*;

/**
 * Message-Driven Bean for async library notifications
 * Syllabus: Message-Driven Beans
 * 
 * Note: Requires JMS provider and EJB container to run.
 */
@MessageDriven(activationConfig = {
    @ActivationConfigProperty(propertyName = "destinationType", propertyValue = "javax.jms.Queue"),
    @ActivationConfigProperty(propertyName = "destination", propertyValue = "java:/jms/queue/LibraryQueue")
})
public class LibraryMessageBean implements MessageListener {

    @Override
    public void onMessage(Message message) {
        try {
            if (message instanceof TextMessage) {
                TextMessage textMessage = (TextMessage) message;
                String content = textMessage.getText();
                System.out.println("MDB Received: " + content);
                processNotification(content);
            }
        } catch (JMSException e) {
            System.err.println("MDB Error: " + e.getMessage());
        }
    }

    private void processNotification(String message) {
        if (message.startsWith("OVERDUE:")) {
            System.out.println("Processing overdue notification: " + message);
        } else if (message.startsWith("RESERVED:")) {
            System.out.println("Processing reservation notification: " + message);
        } else {
            System.out.println("General notification: " + message);
        }
    }
}
