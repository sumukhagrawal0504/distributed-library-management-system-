package com.library.ejb;

import javax.ejb.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Session EJB for Library operations
 * Syllabus: Enterprise Programming, Session EJBs, EJB Clients, 
 *           EJB Transaction Characteristics, EJB Security
 * 
 * Note: Requires an EJB container (e.g., WildFly, GlassFish) to deploy.
 */
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
public class LibrarySessionBean {

    /**
     * Stateless session bean method - no client state between calls
     * Container-managed transaction
     */
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public String searchBook(String title) {
        return "EJB Search Result: Found '" + title + "' in catalog.";
    }

    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public boolean borrowBook(int bookId, int memberId) {
        System.out.println("EJB: Processing borrow - Book:" + bookId + " Member:" + memberId);
        // In real implementation, this would use JPA/JDBC
        return true;
    }

    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public boolean returnBook(int transactionId) {
        System.out.println("EJB: Processing return - Transaction:" + transactionId);
        return true;
    }

    public List<String> getAvailableBooks() {
        List<String> books = new ArrayList<>();
        books.add("Java Complete Reference");
        books.add("Head First Java");
        books.add("Clean Code");
        return books;
    }
}
