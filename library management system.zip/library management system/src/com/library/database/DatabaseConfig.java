package com.library.database;

/**
 * Database configuration constants
 * Syllabus: JDBC - Introduction, JDBC Drivers
 */
public class DatabaseConfig {
    // JDBC configuration for MySQL (change as needed)
    public static final String DB_URL = "jdbc:mysql://localhost:3306/library_db";
    public static final String DB_USER = "root";
    public static final String DB_PASSWORD = "password";
    public static final String DB_DRIVER = "com.mysql.cj.jdbc.Driver";
    
    // SQL to create tables
    public static final String CREATE_BOOKS_TABLE = 
        "CREATE TABLE IF NOT EXISTS books (" +
        "  book_id INT PRIMARY KEY AUTO_INCREMENT," +
        "  title VARCHAR(255) NOT NULL," +
        "  author VARCHAR(255) NOT NULL," +
        "  isbn VARCHAR(20) UNIQUE," +
        "  genre VARCHAR(100)," +
        "  quantity INT DEFAULT 1," +
        "  available_copies INT DEFAULT 1," +
        "  price DECIMAL(10,2) DEFAULT 0.00" +
        ")";
    
    public static final String CREATE_MEMBERS_TABLE = 
        "CREATE TABLE IF NOT EXISTS members (" +
        "  member_id INT PRIMARY KEY AUTO_INCREMENT," +
        "  name VARCHAR(255) NOT NULL," +
        "  email VARCHAR(255) UNIQUE," +
        "  phone VARCHAR(20)," +
        "  membership_type VARCHAR(20) DEFAULT 'GENERAL'," +
        "  member_since DATE DEFAULT (CURRENT_DATE)" +
        ")";
    
    public static final String CREATE_TRANSACTIONS_TABLE = 
        "CREATE TABLE IF NOT EXISTS transactions (" +
        "  transaction_id INT PRIMARY KEY AUTO_INCREMENT," +
        "  book_id INT," +
        "  member_id INT," +
        "  borrow_date DATE DEFAULT (CURRENT_DATE)," +
        "  due_date DATE," +
        "  return_date DATE," +
        "  returned BOOLEAN DEFAULT FALSE," +
        "  fine DECIMAL(10,2) DEFAULT 0.00," +
        "  FOREIGN KEY (book_id) REFERENCES books(book_id)," +
        "  FOREIGN KEY (member_id) REFERENCES members(member_id)" +
        ")";
}
