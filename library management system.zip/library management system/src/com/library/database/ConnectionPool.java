package com.library.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Simple Connection Pool implementation
 * Syllabus: JDBC - Connection Pooling, javax.sql API concepts
 */
public class ConnectionPool {
    private List<Connection> availableConnections;
    private List<Connection> usedConnections;
    private static final int INITIAL_POOL_SIZE = 5;
    private static final int MAX_POOL_SIZE = 10;

    public ConnectionPool() throws SQLException, ClassNotFoundException {
        Class.forName(DatabaseConfig.DB_DRIVER);
        availableConnections = new ArrayList<>();
        usedConnections = new ArrayList<>();
        
        for (int i = 0; i < INITIAL_POOL_SIZE; i++) {
            availableConnections.add(createConnection());
        }
        System.out.println("Connection pool initialized with " + INITIAL_POOL_SIZE + " connections.");
    }

    private Connection createConnection() throws SQLException {
        return DriverManager.getConnection(DatabaseConfig.DB_URL, DatabaseConfig.DB_USER, DatabaseConfig.DB_PASSWORD);
    }

    public synchronized Connection getConnection() throws SQLException {
        if (availableConnections.isEmpty()) {
            if (usedConnections.size() < MAX_POOL_SIZE) {
                availableConnections.add(createConnection());
            } else {
                throw new SQLException("Maximum pool size reached. No available connections.");
            }
        }
        Connection conn = availableConnections.remove(availableConnections.size() - 1);
        usedConnections.add(conn);
        return conn;
    }

    public synchronized void releaseConnection(Connection conn) {
        usedConnections.remove(conn);
        availableConnections.add(conn);
    }

    public int getAvailableCount() { return availableConnections.size(); }
    public int getUsedCount() { return usedConnections.size(); }

    public void shutdown() throws SQLException {
        for (Connection c : availableConnections) c.close();
        for (Connection c : usedConnections) c.close();
        System.out.println("Connection pool shut down.");
    }
}
