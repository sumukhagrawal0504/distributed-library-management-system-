package com.library.database;

import com.library.model.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * JDBC Database Manager - Handles all DB operations
 * Syllabus: JDBC, java.sql API, SQL to Java Type Mapping, Coding Transactions, Connection Pooling
 */
public class DatabaseManager {
    private Connection connection;

    // Establish JDBC Connection
    public void connect() throws SQLException, ClassNotFoundException {
        Class.forName(DatabaseConfig.DB_DRIVER);
        connection = DriverManager.getConnection(
                DatabaseConfig.DB_URL, DatabaseConfig.DB_USER, DatabaseConfig.DB_PASSWORD);
        System.out.println("Database connected successfully.");
    }

    // Initialize database tables
    public void initializeDatabase() throws SQLException {
        try (Statement stmt = connection.createStatement()) {
            stmt.executeUpdate(DatabaseConfig.CREATE_BOOKS_TABLE);
            stmt.executeUpdate(DatabaseConfig.CREATE_MEMBERS_TABLE);
            stmt.executeUpdate(DatabaseConfig.CREATE_TRANSACTIONS_TABLE);
            System.out.println("Database tables initialized.");
        }
    }

    // ---- BOOK CRUD Operations using PreparedStatement ----

    public void insertBook(Book book) throws SQLException {
        String sql = "INSERT INTO books (title, author, isbn, genre, quantity, available_copies, price) VALUES (?,?,?,?,?,?,?)";
        try (PreparedStatement pstmt = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            pstmt.setString(1, book.getTitle());      // SQL VARCHAR -> Java String
            pstmt.setString(2, book.getAuthor());
            pstmt.setString(3, book.getIsbn());
            pstmt.setString(4, book.getGenre());
            pstmt.setInt(5, book.getQuantity());       // SQL INT -> Java int
            pstmt.setInt(6, book.getAvailableCopies());
            pstmt.setDouble(7, book.getPrice());       // SQL DECIMAL -> Java double
            pstmt.executeUpdate();

            ResultSet rs = pstmt.getGeneratedKeys();
            if (rs.next()) {
                book.setBookId(rs.getInt(1));
            }
            System.out.println("Book inserted: " + book.getTitle());
        }
    }

    public Book getBookById(int bookId) throws SQLException {
        String sql = "SELECT * FROM books WHERE book_id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, bookId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return mapResultSetToBook(rs);
            }
        }
        return null;
    }

    public List<Book> getAllBooks() throws SQLException {
        List<Book> books = new ArrayList<>();
        String sql = "SELECT * FROM books ORDER BY title";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                books.add(mapResultSetToBook(rs));
            }
        }
        return books;
    }

    public void updateBook(Book book) throws SQLException {
        String sql = "UPDATE books SET title=?, author=?, isbn=?, genre=?, quantity=?, available_copies=?, price=? WHERE book_id=?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, book.getTitle());
            pstmt.setString(2, book.getAuthor());
            pstmt.setString(3, book.getIsbn());
            pstmt.setString(4, book.getGenre());
            pstmt.setInt(5, book.getQuantity());
            pstmt.setInt(6, book.getAvailableCopies());
            pstmt.setDouble(7, book.getPrice());
            pstmt.setInt(8, book.getBookId());
            pstmt.executeUpdate();
        }
    }

    public void deleteBook(int bookId) throws SQLException {
        String sql = "DELETE FROM books WHERE book_id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, bookId);
            pstmt.executeUpdate();
        }
    }

    // ---- MEMBER CRUD Operations ----

    public void insertMember(Member member) throws SQLException {
        String sql = "INSERT INTO members (name, email, phone, membership_type) VALUES (?,?,?,?)";
        try (PreparedStatement pstmt = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            pstmt.setString(1, member.getName());
            pstmt.setString(2, member.getEmail());
            pstmt.setString(3, member.getPhone());
            pstmt.setString(4, member.getMembershipType());
            pstmt.executeUpdate();
            
            ResultSet rs = pstmt.getGeneratedKeys();
            if (rs.next()) member.setMemberId(rs.getInt(1));
        }
    }

    public List<Member> getAllMembers() throws SQLException {
        List<Member> members = new ArrayList<>();
        String sql = "SELECT * FROM members";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Member m = new Member(
                    rs.getInt("member_id"),
                    rs.getString("name"),
                    rs.getString("email"),
                    rs.getString("phone"),
                    rs.getString("membership_type")
                );
                m.setMemberSince(rs.getDate("member_since"));
                members.add(m);
            }
        }
        return members;
    }

    // ---- TRANSACTION with JDBC Transaction Support ----

    /**
     * Borrow book with JDBC transaction (commit/rollback)
     * Syllabus: Coding Transactions
     */
    public void borrowBookTransaction(int bookId, int memberId) throws SQLException {
        connection.setAutoCommit(false); // Start transaction
        try {
            // Check book availability
            Book book = getBookById(bookId);
            if (book == null || book.getAvailableCopies() <= 0) {
                throw new SQLException("Book not available for borrowing.");
            }

            // Insert transaction record
            String insertSql = "INSERT INTO transactions (book_id, member_id, borrow_date, due_date) VALUES (?,?,CURRENT_DATE, DATE_ADD(CURRENT_DATE, INTERVAL 14 DAY))";
            try (PreparedStatement pstmt = connection.prepareStatement(insertSql)) {
                pstmt.setInt(1, bookId);
                pstmt.setInt(2, memberId);
                pstmt.executeUpdate();
            }

            // Update book available copies
            String updateSql = "UPDATE books SET available_copies = available_copies - 1 WHERE book_id = ?";
            try (PreparedStatement pstmt = connection.prepareStatement(updateSql)) {
                pstmt.setInt(1, bookId);
                pstmt.executeUpdate();
            }

            connection.commit(); // Commit transaction
            System.out.println("Borrow transaction committed successfully.");
        } catch (SQLException e) {
            connection.rollback(); // Rollback on error
            System.err.println("Transaction rolled back: " + e.getMessage());
            throw e;
        } finally {
            connection.setAutoCommit(true); // Restore auto-commit
        }
    }

    // Helper method - SQL to Java Type Mapping demonstration
    private Book mapResultSetToBook(ResultSet rs) throws SQLException {
        Book book = new Book();
        book.setBookId(rs.getInt("book_id"));           // SQL INT -> Java int
        book.setTitle(rs.getString("title"));            // SQL VARCHAR -> Java String
        book.setAuthor(rs.getString("author"));
        book.setIsbn(rs.getString("isbn"));
        book.setGenre(rs.getString("genre"));
        book.setQuantity(rs.getInt("quantity"));
        book.setAvailableCopies(rs.getInt("available_copies"));
        book.setPrice(rs.getDouble("price"));            // SQL DECIMAL -> Java double
        return book;
    }

    // Close connection
    public void disconnect() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
                System.out.println("Database disconnected.");
            }
        } catch (SQLException e) {
            System.err.println("Error closing connection: " + e.getMessage());
        }
    }
}
