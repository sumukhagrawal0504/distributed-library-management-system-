package com.library.io;

import com.library.model.*;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Handles file I/O and Object Serialization
 * Syllabus: Input/Output, Serialization, Object Serialization
 */
public class FileHandler {

    // Object Serialization - Save library data
    public static void saveBooks(List<Book> books, String filename) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filename))) {
            oos.writeObject(books);
            System.out.println("Books saved to " + filename + " (Serialization)");
        } catch (IOException e) {
            System.err.println("Error saving books: " + e.getMessage());
        }
    }

    // Object Deserialization - Load library data
    @SuppressWarnings("unchecked")
    public static List<Book> loadBooks(String filename) {
        List<Book> books = new ArrayList<>();
        File file = new File(filename);
        if (!file.exists()) return books;
        
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filename))) {
            books = (List<Book>) ois.readObject();
            System.out.println("Books loaded from " + filename + " (Deserialization)");
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error loading books: " + e.getMessage());
        }
        return books;
    }

    // Save members using serialization
    public static void saveMembers(List<Member> members, String filename) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filename))) {
            oos.writeObject(members);
            System.out.println("Members saved to " + filename);
        } catch (IOException e) {
            System.err.println("Error saving members: " + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    public static List<Member> loadMembers(String filename) {
        List<Member> members = new ArrayList<>();
        File file = new File(filename);
        if (!file.exists()) return members;
        
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filename))) {
            members = (List<Member>) ois.readObject();
            System.out.println("Members loaded from " + filename);
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error loading members: " + e.getMessage());
        }
        return members;
    }

    // Text file I/O - Export book catalog
    public static void exportBookCatalog(List<Book> books, String filename) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename))) {
            writer.write("=== LIBRARY BOOK CATALOG ===\n");
            writer.write(String.format("%-5s %-30s %-20s %-15s %-10s %-10s%n",
                    "ID", "Title", "Author", "ISBN", "Available", "Price"));
            writer.write("-".repeat(95) + "\n");
            
            for (Book b : books) {
                writer.write(String.format("%-5d %-30s %-20s %-15s %-10d Rs.%-7.2f%n",
                        b.getBookId(), b.getTitle(), b.getAuthor(), b.getIsbn(),
                        b.getAvailableCopies(), b.getPrice()));
            }
            System.out.println("Catalog exported to " + filename);
        } catch (IOException e) {
            System.err.println("Error exporting catalog: " + e.getMessage());
        }
    }

    // Text file I/O - Read and display catalog
    public static void readCatalog(String filename) {
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            System.out.println("\n--- Reading Catalog from File ---");
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
        } catch (FileNotFoundException e) {
            System.err.println("Catalog file not found: " + filename);
        } catch (IOException e) {
            System.err.println("Error reading catalog: " + e.getMessage());
        }
    }
}
