package com.library.servlet;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

/**
 * Library Servlet - Web interface for library operations
 * Syllabus: Servlets, The Servlet API, Building Web Application
 * 
 * Note: Requires a servlet container (Tomcat/Jetty) to run.
 * Deploy as WAR file with web.xml configuration.
 */
public class LibraryServlet extends HttpServlet {

    @Override
    public void init(ServletConfig config) throws ServletException {
        super.init(config);
        System.out.println("LibraryServlet initialized.");
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        String action = request.getParameter("action");
        
        out.println("<html><head><title>Library Management</title></head><body>");
        out.println("<h1>Library Management System</h1>");
        
        if ("search".equals(action)) {
            String query = request.getParameter("query");
            out.println("<h2>Search Results for: " + query + "</h2>");
            out.println("<p>Results would be fetched from database via JDBC.</p>");
        } else if ("list".equals(action)) {
            out.println("<h2>All Books</h2>");
            out.println("<table border='1'>");
            out.println("<tr><th>ID</th><th>Title</th><th>Author</th><th>Available</th></tr>");
            out.println("<tr><td>1</td><td>Java Complete Reference</td><td>Herbert Schildt</td><td>Yes</td></tr>");
            out.println("<tr><td>2</td><td>Head First Java</td><td>Kathy Sierra</td><td>Yes</td></tr>");
            out.println("</table>");
        } else {
            // Default - show search form
            out.println("<form method='GET'>");
            out.println("<input type='hidden' name='action' value='search'>");
            out.println("Search: <input type='text' name='query'>");
            out.println("<input type='submit' value='Search'>");
            out.println("</form>");
            out.println("<br><a href='?action=list'>View All Books</a>");
        }

        out.println("<hr><p><small>Powered by LibraryServlet</small></p>");
        out.println("</body></html>");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        // Handle form submissions (add book, borrow, return)
        String action = request.getParameter("action");
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        out.println("<html><body>");
        out.println("<h2>Action: " + action + " processed.</h2>");
        out.println("<a href='/library'>Back to Home</a>");
        out.println("</body></html>");
    }

    @Override
    public void destroy() {
        System.out.println("LibraryServlet destroyed.");
    }
}
