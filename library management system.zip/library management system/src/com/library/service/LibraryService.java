package com.library.service;

import com.library.interfaces.LibraryOperations;
import com.library.model.*;
import com.library.exceptions.*;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Core library service implementing business logic
 * Syllabus: OOP, Interfaces, Exception Handling, Arrays
 */
public class LibraryService implements LibraryOperations {
    private List<Book> books;
    private List<Member> members;
    private List<Transaction> transactions;
    private int nextTransactionId;

    public LibraryService() {
        books = new ArrayList<>();
        members = new ArrayList<>();
        transactions = new ArrayList<>();
        nextTransactionId = 1;
    }

    @Override
    public void addBook(Book book) {
        books.add(book);
        System.out.println("Book added: " + book.getTitle());
    }

    @Override
    public void removeBook(int bookId) {
        books.removeIf(b -> b.getBookId() == bookId);
    }

    @Override
    public Book searchBookById(int bookId) {
        for (Book b : books) {
            if (b.getBookId() == bookId) return b;
        }
        return null;
    }

    @Override
    public List<Book> searchBookByTitle(String title) {
        List<Book> result = new ArrayList<>();
        for (Book b : books) {
            if (b.getTitle().toLowerCase().contains(title.toLowerCase())) {
                result.add(b);
            }
        }
        return result;
    }

    @Override
    public List<Book> searchBookByAuthor(String author) {
        List<Book> result = new ArrayList<>();
        for (Book b : books) {
            if (b.getAuthor().toLowerCase().contains(author.toLowerCase())) {
                result.add(b);
            }
        }
        return result;
    }

    @Override
    public List<Book> getAllBooks() { return new ArrayList<>(books); }

    @Override
    public void addMember(Member member) {
        members.add(member);
        System.out.println("Member registered: " + member.getName());
    }

    @Override
    public void removeMember(int memberId) {
        members.removeIf(m -> m.getMemberId() == memberId);
    }

    @Override
    public Member searchMemberById(int memberId) {
        for (Member m : members) {
            if (m.getMemberId() == memberId) return m;
        }
        return null;
    }

    @Override
    public List<Member> getAllMembers() { return new ArrayList<>(members); }

    @Override
    public Transaction borrowBook(int bookId, int memberId) throws LibraryException {
        Book book = searchBookById(bookId);
        if (book == null) throw new BookNotFoundException(bookId);
        
        Member member = searchMemberById(memberId);
        if (member == null) throw new MemberNotFoundException(memberId);
        
        if (!book.isAvailable()) throw new BookNotAvailableException("Book '" + book.getTitle() + "' is not available.");
        if (!member.canBorrow()) throw new MaxBooksExceededException(
            "Member '" + member.getName() + "' has reached max borrow limit of " + member.getMaxBooksAllowed());

        Transaction t = new Transaction(nextTransactionId++, bookId, memberId);
        book.borrowBook();
        member.addTransaction(t);
        transactions.add(t);
        System.out.println("Book '" + book.getTitle() + "' borrowed by '" + member.getName() + "'");
        return t;
    }

    @Override
    public Transaction returnBook(int transactionId) throws LibraryException {
        Transaction t = null;
        for (Transaction tr : transactions) {
            if (tr.getTransactionId() == transactionId && !tr.isReturned()) {
                t = tr;
                break;
            }
        }
        if (t == null) throw new LibraryException("Active transaction with ID " + transactionId + " not found.");
        
        t.markReturned();
        Book book = searchBookById(t.getBookId());
        if (book != null) book.returnBook();
        
        if (t.getFine() > 0) {
            System.out.println("Book returned with fine: Rs. " + t.getFine());
        } else {
            System.out.println("Book returned successfully. No fine.");
        }
        return t;
    }

    @Override
    public List<Transaction> getAllTransactions() { return new ArrayList<>(transactions); }

    public List<Transaction> getActiveTransactions() {
        List<Transaction> active = new ArrayList<>();
        for (Transaction t : transactions) {
            if (!t.isReturned()) active.add(t);
        }
        return active;
    }

    // For array demonstration
    public Book[] getBooksAsArray() {
        return books.toArray(new Book[0]);
    }

    public void setBooks(List<Book> books) { this.books = books; }
    public void setMembers(List<Member> members) { this.members = members; }
    public void setTransactions(List<Transaction> transactions) { this.transactions = transactions; }
}
