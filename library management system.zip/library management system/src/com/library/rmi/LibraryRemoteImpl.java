package com.library.rmi;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.List;

/**
 * RMI Implementation
 * Syllabus: Remote Method Invocation
 */
public class LibraryRemoteImpl extends UnicastRemoteObject implements LibraryRemote {

    public LibraryRemoteImpl() throws RemoteException {
        super();
    }

    @Override
    public String searchBook(String title) throws RemoteException {
        System.out.println("RMI: Searching for book - " + title);
        return "Found: " + title + " (RMI Demo Response)";
    }

    @Override
    public List<String> listAllBooks() throws RemoteException {
        List<String> books = new ArrayList<>();
        books.add("Java Complete Reference");
        books.add("Head First Java");
        books.add("Clean Code");
        return books;
    }

    @Override
    public boolean borrowBook(int bookId, int memberId) throws RemoteException {
        System.out.println("RMI: Borrow request - Book:" + bookId + " Member:" + memberId);
        return true;
    }

    @Override
    public boolean returnBook(int transactionId) throws RemoteException {
        System.out.println("RMI: Return request - Transaction:" + transactionId);
        return true;
    }

    @Override
    public String getLibraryStatus() throws RemoteException {
        return "Library is OPEN. Total books: 100, Members: 50";
    }
}
