package com.library.rmi;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

/**
 * RMI Remote Interface for Library
 * Syllabus: Remote Method Invocation (RMI)
 */
public interface LibraryRemote extends Remote {
    String searchBook(String title) throws RemoteException;
    List<String> listAllBooks() throws RemoteException;
    boolean borrowBook(int bookId, int memberId) throws RemoteException;
    boolean returnBook(int transactionId) throws RemoteException;
    String getLibraryStatus() throws RemoteException;
}
